StabuliSerialCom is an eclipes project folder, just import it and it'll work, you may
have to play around with project dependences in the build options to make sure it is 
dependent on RXTXcomm.jar

The other files are the individual files required if you aren't using eclipse, RXTXcomm.jar
is required for the program to run.

Should be good to go, if you have trouble, try googling "Java Arduino Serial communication",
The programs and problems are very similar.